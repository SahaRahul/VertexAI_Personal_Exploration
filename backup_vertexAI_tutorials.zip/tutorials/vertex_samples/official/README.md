# Google Cloud Vertex AI Official Notebooks

The official notebooks are a collection of curated and non-curated notebooks authored by Google Cloud staff members. The curated notebooks are linked to in the [Vertex AI online web documentation](https://cloud.google.com/vertex-ai/docs/tutorials/jupyter-notebooks).

The official notebooks are organized by Google Cloud Vertex AI services.

