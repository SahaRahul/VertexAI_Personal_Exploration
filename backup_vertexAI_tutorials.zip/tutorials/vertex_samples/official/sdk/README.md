
[AutoML Video Classification Example](https://github.com/GoogleCloudPlatform/vertex-ai-samples/blob/main/notebooks/official/sdk/SDK_AutoML_Video_Classification.ipynb)

```
The objective of this notebook is to build a AutoML Video Classification Model.

The steps performed include the following:

- Set your task name, and GCS prefix
- Copy AutoML video demo train data for creating managed dataset
- Create a dataset on Vertex AI.
- Configure a training job
- Launch a training job and create a model on Vertex AI
- Copy AutoML Video Demo Prediction Data for creating batch prediction job
- Perform batch prediction job on the model

```

&nbsp;&nbsp;&nbsp;Learn more about [Classification for video data](https://cloud.google.com/vertex-ai/docs/training-overview#classification_for_videos).


[Custom training using Python package, managed text dataset, and TF Serving container](https://github.com/GoogleCloudPlatform/vertex-ai-samples/blob/main/notebooks/official/sdk/SDK_Custom_Training_Python_Package_Managed_Text_Dataset_Tensorflow_Serving_Container.ipynb)

```
Learn how to create a Custom Model using Custom Python Package Training and you learn how to serve the model using TensorFlow-Serving Container for online prediction.

The steps performed include:

- Create utility functions to download data and prepare csv files for creating Vertex AI Managed    Dataset
- Download Data
- Prepare CSV Files for Creating Managed Dataset
- Create Custom Training Python Package
- Create TensorFlow Serving Container
- Run Custom Python Package Training with Managed Text Dataset
- Deploy a Model and Create an Endpoint on Vertex AI
- Predict on the Endpoint
- Create a Batch Prediction Job on the Model

```

&nbsp;&nbsp;&nbsp;Learn more about [Custom training](https://cloud.google.com/vertex-ai/docs/training/custom-training).


[Train a pytorch model with Vertex AI SDK 2.0 and Bigframes](https://github.com/GoogleCloudPlatform/vertex-ai-samples/blob/main/notebooks/official/sdk/sdk2_bigframes_pytorch.ipynb)

```
Learn to use `Vertex AI SDK 2.

The steps performed include:

- Initialize a dataframe from a BigQuery table and split the dataset
- Perform transformations as a Vertex AI remote training.
- Train the model remotely and evaluate the model locally

```

&nbsp;&nbsp;&nbsp;Learn more about [bigframes](https://cloud.google.com/bigquery/docs/).


[Train a scikit-learn model with Vertex AI SDK 2.0 and Bigframes](https://github.com/GoogleCloudPlatform/vertex-ai-samples/blob/main/notebooks/official/sdk/sdk2_bigframes_sklearn.ipynb)

```
Learn to use `Vertex AI SDK 2.

The steps performed include:

- Initialize a dataframe from a BigQuery table and split the dataset
- Perform transformations as a Vertex AI remote training.
- Train the model remotely and evaluate the model locally

```

&nbsp;&nbsp;&nbsp;Learn more about [bigframes](https://cloud.google.com/bigquery/docs/).


[Train a Tensorflow Keras model with Vertex AI SDK 2.0 and Bigframes](https://github.com/GoogleCloudPlatform/vertex-ai-samples/blob/main/notebooks/official/sdk/sdk2_bigframes_tensorflow.ipynb)

```
Learn to use `Vertex AI SDK 2.

The steps performed include:

- Initialize a dataframe from a BigQuery table and split the dataset
- Perform transformations as a Vertex AI remote training.
- Train the model remotely and evaluate the model locally

```

&nbsp;&nbsp;&nbsp;Learn more about [bigframes](https://cloud.google.com/bigquery/docs/).

